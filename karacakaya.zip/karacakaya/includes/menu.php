<?php
// Bu dosya sadece menü içeriğini barındırır.
// Header.php tarafından #sidebar div'inin içine dahil edilecektir.
?>
<nav>
    <ul>
        <li><a href="dashboard.php">Anasayfa</a></li>
        <li><a href="orders.php">Sipariş Yönetimi</a></li>
        <li><a href="customers.php">Müşteri Yönetimi</a></li>
        <li><a href="products.php">Ürün Yönetimi</a></li>
        <li><a href="customer_product_prices.php">Müşteri Ürün Fiyatları</a></li>
       <li> <a href="accounting.php" class="sidebar-item">Cari Hesap Yönetimi</a></li>
        <li><a href="shipments.php">Sevkiyat Yönetimi</a></li>
        <li><a href="invoicing.php">Faturalandırma</a></li>
        <li><a href="users.php">Kullanıcı Yönetimi</a></li>
        <li><a href="reports.php">Raporlar</a></li>
        <li><a href="settings.php">Ayarlar</a></li>
        <li><a href="logout.php">Çıkış Yap</a></li>
    </ul>
</nav>